﻿//mis 3033
//lc 2-19
//113529005
//camille duryea

using LC0219.Data;
using LC0219.Models;
using System.Text.Json;

Console.WriteLine("Existing Database");

StudentDB db;
db = new StudentDB();

var r = db.Students;

JsonSerializerOptions opts = new JsonSerializerOptions();
opts.WriteIndented = true;

string dataStr = JsonSerializer.Serialize(r, opts);
Console.WriteLine(dataStr);
File.WriteAllText("data.json", dataStr);